#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <climits>
#include <unordered_map>
#include <unordered_set>
#include <algorithm> // Include this for std::reverse

using namespace std;

class MetroSystem {
private:
    // Graph representation
    unordered_map<string, vector<pair<string, int>>> graph;

    // Helper function for BFS
    void bfs(const string& start, const string& end) {
        unordered_map<string, bool> visited;
        unordered_map<string, string> parent;
        queue<string> q;

        q.push(start);
        visited[start] = true;

        while (!q.empty()) {
            string node = q.front();
            q.pop();

            if (node == end) {
                // Path found, backtrack to print the path
                vector<string> path;
                while (node != start) {
                    path.push_back(node);
                    node = parent[node];
                }
                path.push_back(start);
                reverse(path.begin(), path.end()); // Fix: Include <algorithm> for this function

                cout << "BFS Path: ";
                for (const auto& p : path) {
                    cout << p << " ";
                }
                cout << endl;
                return;
            }

            for (const auto& neighbor : graph[node]) {
                if (!visited[neighbor.first]) {
                    visited[neighbor.first] = true;
                    parent[neighbor.first] = node;
                    q.push(neighbor.first);
                }
            }
        }
        cout << "No path found using BFS." << endl;
    }

    // Helper function for DFS
    void dfs(const string& start, const string& end, unordered_set<string>& visited, vector<string>& path) {
        visited.insert(start);
        path.push_back(start);

        if (start == end) {
            cout << "DFS Path: ";
            for (const auto& p : path) {
                cout << p << " ";
            }
            cout << endl;
            return;
        }

        for (const auto& neighbor : graph[start]) {
            if (visited.find(neighbor.first) == visited.end()) {
                dfs(neighbor.first, end, visited, path);
                if (path.back() == end) return; // Found path, exit recursion
            }
        }

        path.pop_back(); // Backtrack
    }

public:
    // Add a connection between two stations with a given fare
    void addConnection(const string& from, const string& to, int fare) {
        graph[from].emplace_back(to, fare);
        graph[to].emplace_back(from, fare); // For undirected graph
    }

    // Calculate minimum fare using Dijkstra's algorithm
    void calculateFare(const string& start, const string& end) {
        unordered_map<string, int> distances;
        unordered_map<string, string> parent;
        priority_queue<pair<int, string>, vector<pair<int, string>>, greater<>> pq;

        for (const auto& [station, _] : graph) {
            distances[station] = INT_MAX;
        }
        distances[start] = 0;
        pq.push({0, start});

        while (!pq.empty()) {
            string node = pq.top().second;
            int dist = pq.top().first;
            pq.pop();

            if (node == end) {
                cout << "Minimum fare from " << start << " to " << end << " is " << dist << endl;
                return;
            }

            for (const auto& neighbor : graph[node]) {
                int newDist = dist + neighbor.second;
                if (newDist < distances[neighbor.first]) {
                    distances[neighbor.first] = newDist;
                    parent[neighbor.first] = node;
                    pq.push({newDist, neighbor.first});
                }
            }
        }
        cout << "No path found using Dijkstra's algorithm." << endl;
    }

    // Find and print paths using DFS
    void findPathDFS(const string& start, const string& end) {
        unordered_set<string> visited;
        vector<string> path;
        dfs(start, end, visited, path);
    }

    // Find and print paths using BFS
    void findPathBFS(const string& start, const string& end) {
        bfs(start, end);
    }
};

int main() {
    MetroSystem metro;

    // Adding connections
    metro.addConnection("A", "B", 10);
    metro.addConnection("A", "C", 15);
    metro.addConnection("B", "D", 12);
    metro.addConnection("C", "D", 10);
    metro.addConnection("D", "E", 2);

    // Calculate minimum fare
    metro.calculateFare("A", "E");

    // Find paths using DFS and BFS
    metro.findPathDFS("A", "E");
    metro.findPathBFS("A", "E");

    return 0;
}